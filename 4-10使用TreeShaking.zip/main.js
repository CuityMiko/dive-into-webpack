import {funcA} from "./util";

funcA();
